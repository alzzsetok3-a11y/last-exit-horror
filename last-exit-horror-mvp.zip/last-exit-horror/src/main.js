import * as THREE from 'three';
import './style.css';

const $ = (id) => document.getElementById(id);
const DEFAULT_KEYS = { forward:'KeyW', back:'KeyS', left:'KeyA', right:'KeyD', run:'ShiftLeft', crouch:'ControlLeft', interact:'KeyE', flashlight:'KeyF', pause:'Escape' };
const ACTION_NAMES = { forward:'Maju', back:'Mundur', left:'Ke kiri', right:'Ke kanan', run:'Lari', crouch:'Jongkok', interact:'Interaksi', flashlight:'Senter', pause:'Jeda' };
const DIFFICULTY = {
  normal: { label:'NORMAL', speed:1, chase:1, items:3, battery:100, flicker:0.015 },
  medium: { label:'MENENGAH', speed:1.2, chase:1.35, items:4, battery:82, flicker:0.035 },
  nightmare: { label:'SANGAT SERAM', speed:1.42, chase:1.7, items:5, battery:65, flicker:0.075 }
};
const MAPS = {
  tunnel: { label:'Terowongan Gelap', length:44, width:10, color:0x26353a, floor:0x151a1c, objective:'Cari sekering, aktifkan panel, lalu temukan pintu keluar.' },
  house: { label:'Rumah Tua Berhantu', length:36, width:26, color:0x423b36, floor:0x241d1a, objective:'Kumpulkan kunci-kunci rumah dan temukan pintu depan.' },
  hospital: { label:'Rumah Sakit Terbengkalai', length:40, width:18, color:0x344440, floor:0x1a211f, objective:'Temukan kartu akses dan pulihkan pintu darurat.' }
};
let scene, camera, renderer, clock, flashlight, ambientLight, worldGroup, enemy, exitObject, panelObject;
let running = false, paused = true, ended = false, pointerLocked = false;
let selectedMap = 'tunnel', selectedDifficulty = 'normal';
let player = { x:0, z:0, yaw:0, pitch:0, stamina:100, battery:100, health:100, crouched:false };
let keysDown = new Set(), interactables = [], collected = 0, requiredItems = 3, enemyState = 'patrol';
let enemyTimer = 0, flickerTimer = 0, toastTimer = 0, toastMessage = '';
let audioCtx = null, ambienceGain = null, heartbeatOsc = null;
let settings = loadSettings();
let keyBindings = { ...DEFAULT_KEYS, ...(settings.keys || {}) };
let remapAction = null;
let lastNoise = 0, exitUnlocked = false, gameTime = 0;
const raycaster = new THREE.Raycaster();
const forward = new THREE.Vector3();
const tmpVec = new THREE.Vector3();

function loadSettings() {
  try { return { volume:65, sensitivity:0.8, brightness:100, quality:'medium', resolution:'window', ...(JSON.parse(localStorage.getItem('tle-settings') || '{}')) }; }
  catch { return { volume:65, sensitivity:0.8, brightness:100, quality:'medium', resolution:'window' }; }
}
function saveSettings() {
  settings = {
    volume:Number($('volume').value), sensitivity:Number($('sensitivity').value)/10,
    brightness:Number($('brightness').value), quality:$('quality').value,
    resolution:$('resolution').value, keys:keyBindings
  };
  localStorage.setItem('tle-settings', JSON.stringify(settings));
  applySettings(); showToast('Pengaturan disimpan.');
}
function applySettings() {
  document.documentElement.style.setProperty('--brightness', String((settings.brightness || 100)/100));
  if (renderer) {
    const ratio = settings.quality === 'low' ? 0.75 : settings.quality === 'high' ? Math.min(devicePixelRatio, 2) : Math.min(devicePixelRatio, 1.35);
    renderer.setPixelRatio(ratio);
    renderer.shadowMap.enabled = settings.quality !== 'low';
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    resizeRenderer();
  }
  if (ambienceGain) ambienceGain.gain.value = (settings.volume || 0) / 100 * 0.045;
}
function resizeRenderer() {
  if (!renderer || !camera) return;
  const resolution = settings.resolution || 'window';
  let w = window.innerWidth, h = window.innerHeight;
  if (resolution !== 'window') {
    const [rw, rh] = resolution.split('x').map(Number);
    w = Math.min(window.innerWidth, rw); h = Math.min(window.innerHeight, rh);
  }
  renderer.setSize(w, h, false);
  renderer.domElement.style.width = '100vw'; renderer.domElement.style.height = '100vh';
  camera.aspect = window.innerWidth / window.innerHeight;
  camera.updateProjectionMatrix();
}
function setView(view) {
  document.querySelectorAll('.menu-view').forEach(el => el.classList.add('hidden'));
  $(view).classList.remove('hidden');
  $('overlay').classList.remove('hidden');
}
function showMainMenu() {
  if (document.pointerLockElement) document.exitPointerLock();
  running = false; paused = true; ended = false;
  $('hud').classList.add('hidden');
  $('menuTitle').innerHTML = 'THE LAST<br><em>EXIT</em>';
  $('menuSubtitle').textContent = 'Malam ini, jangan biarkan sesuatu menemukanmu.';
  setView('mainMenu');
}
function showToast(message) {
  toastMessage = message; toastTimer = 3.2;
  $('toast').textContent = message; $('toast').classList.add('visible');
}
function hideOverlay() { $('overlay').classList.add('hidden'); }
function formatKey(code) {
  const map = { ShiftLeft:'Shift Kiri', ShiftRight:'Shift Kanan', ControlLeft:'Ctrl Kiri', ControlRight:'Ctrl Kanan', Escape:'Esc', Space:'Spasi', Mouse0:'Klik Kiri' };
  if (map[code]) return map[code];
  if (code.startsWith('Key')) return code.slice(3);
  if (code.startsWith('Digit')) return code.slice(5);
  return code.replace('Arrow','Panah ');
}
function renderBindings() {
  const host = $('keyBindings'); host.innerHTML = '';
  Object.entries(keyBindings).forEach(([action, code]) => {
    const row = document.createElement('div'); row.className = 'binding-row';
    const name = document.createElement('span'); name.textContent = ACTION_NAMES[action];
    const button = document.createElement('button'); button.textContent = remapAction === action ? 'TEKAN TOMBOL...' : formatKey(code);
    if (remapAction === action) button.classList.add('listening');
    button.addEventListener('click', () => { remapAction = action; renderBindings(); });
    row.append(name, button); host.append(row);
  });
}
function openControls(fromPause=false) { renderBindings(); setView('controlsMenu'); $('controlsMenu').dataset.fromPause = fromPause ? '1':'0'; }
function backFromSubmenu() {
  const fromPause = $('controlsMenu').dataset.fromPause === '1' || $('settingsMenu').dataset.fromPause === '1';
  if (fromPause && running) setView('pauseMenu'); else setView('mainMenu');
}
function setupMenu() {
  $('volume').value = settings.volume; $('sensitivity').value = settings.sensitivity*10; $('brightness').value = settings.brightness;
  $('quality').value = settings.quality; $('resolution').value = settings.resolution;
  updateSettingLabels();
  ['volume','sensitivity','brightness'].forEach(id => $(id).addEventListener('input', updateSettingLabels));
  $('startBtn').onclick = () => startGame();
  $('mapBtn').onclick = () => setView('mapMenu');
  $('settingsBtn').onclick = () => { $('settingsMenu').dataset.fromPause='0'; setView('settingsMenu'); };
  $('controlsBtn').onclick = () => openControls(false);
  $('mapConfirm').onclick = () => { selectedMap=$('mapSelect').value; selectedDifficulty=$('difficultySelect').value; setView('mainMenu'); $('menuSubtitle').textContent=`${MAPS[selectedMap].label} · ${DIFFICULTY[selectedDifficulty].label}`; };
  $('saveSettings').onclick = saveSettings;
  $('fullscreen').onclick = async () => { try { if (!document.fullscreenElement) await document.documentElement.requestFullscreen(); else await document.exitFullscreen(); } catch { showToast('Mode layar penuh tidak didukung browser ini.'); } };
  $('resetKeys').onclick = () => { keyBindings={...DEFAULT_KEYS}; renderBindings(); localStorage.setItem('tle-settings',JSON.stringify({...settings,keys:keyBindings})); showToast('Tombol dikembalikan ke awal.'); };
  document.querySelectorAll('.backBtn').forEach(b => b.onclick = backFromSubmenu);
  $('resumeBtn').onclick = resumeGame;
  $('restartBtn').onclick = () => startGame();
  $('pauseSettingsBtn').onclick = () => { $('settingsMenu').dataset.fromPause='1'; setView('settingsMenu'); };
  $('pauseControlsBtn').onclick = () => openControls(true);
  $('homeBtn').onclick = showMainMenu;
  $('againBtn').onclick = () => startGame();
  $('endHomeBtn').onclick = showMainMenu;
}
function updateSettingLabels() {
  $('volumeValue').textContent = `${$('volume').value}%`;
  $('sensitivityValue').textContent = (Number($('sensitivity').value)/10).toFixed(1);
  $('brightnessValue').textContent = `${$('brightness').value}%`;
}
function initThree() {
  scene = new THREE.Scene();
  scene.background = new THREE.Color(0x05080a);
  scene.fog = new THREE.FogExp2(0x070b0d, 0.038);
  camera = new THREE.PerspectiveCamera(76, window.innerWidth/window.innerHeight, 0.08, 100);
  camera.position.set(0, 1.65, 0);
  renderer = new THREE.WebGLRenderer({ antialias:true, powerPreference:'high-performance' });
  renderer.outputColorSpace = THREE.SRGBColorSpace;
  renderer.toneMapping = THREE.ACESFilmicToneMapping;
  renderer.toneMappingExposure = 1.1;
  renderer.shadowMap.enabled = true;
  $('game').appendChild(renderer.domElement);
  worldGroup = new THREE.Group(); scene.add(worldGroup);
  ambientLight = new THREE.HemisphereLight(0x72838a, 0x08090a, 0.42); scene.add(ambientLight);
  const moon = new THREE.DirectionalLight(0x9bb4c4, 0.25); moon.position.set(-5,10,2); moon.castShadow=true; scene.add(moon);
  flashlight = new THREE.SpotLight(0xdce9ef, 34, 18, Math.PI/7, 0.45, 1.4);
  flashlight.position.set(0,0,0); flashlight.castShadow=true; flashlight.target.position.set(0,0,-1);
  camera.add(flashlight); camera.add(flashlight.target); scene.add(camera);
  clock = new THREE.Clock();
  applySettings();
  window.addEventListener('resize', resizeRenderer);
}
function material(color, roughness=0.88, opts={}) {
  return new THREE.MeshStandardMaterial({ color, roughness, metalness:opts.metalness||0, side:opts.side||THREE.FrontSide, emissive:opts.emissive||0x000000, emissiveIntensity:opts.emissiveIntensity||0 });
}
function box(parent, x,y,z, sx,sy,sz, mat, opts={}) {
  const mesh = new THREE.Mesh(new THREE.BoxGeometry(sx,sy,sz),mat);
  mesh.position.set(x,y,z); mesh.castShadow = opts.castShadow !== false; mesh.receiveShadow=true; parent.add(mesh); return mesh;
}
function makeLamp(x,y,z,color=0x8da9b0,intensity=1.2) {
  const bulb = new THREE.PointLight(color,intensity,8,2); bulb.position.set(x,y,z); worldGroup.add(bulb);
  const casing = new THREE.Mesh(new THREE.BoxGeometry(.28,.08,.28),material(0x111617)); casing.position.set(x,y+.12,z); worldGroup.add(casing);
  return bulb;
}
function createEnemy() {
  const group = new THREE.Group();
  const dark = material(0x09090b,0.95), face = material(0xafa7a0,0.8,{emissive:0x241a18,emissiveIntensity:.35});
  const body = new THREE.Mesh(new THREE.CapsuleGeometry(.34,.95,4,7),dark); body.position.y=1.05; body.castShadow=true; group.add(body);
  const head = new THREE.Mesh(new THREE.SphereGeometry(.29,10,8),face); head.position.y=1.86; head.scale.set(.8,1.1,.75); head.castShadow=true; group.add(head);
  const eyeMat = new THREE.MeshBasicMaterial({color:0xff2929});
  for (const x of [-.1,.1]) { const eye=new THREE.Mesh(new THREE.SphereGeometry(.035,6,5),eyeMat); eye.position.set(x,1.9,-.22); group.add(eye); }
  group.position.set(0,0,-14); group.userData={home:new THREE.Vector3(0,0,-14),phase:Math.random()*10};
  worldGroup.add(group); return group;
}
function clearWorld() {
  if (!worldGroup) return;
  scene.remove(worldGroup);
  worldGroup.traverse(o => { if (o.geometry) o.geometry.dispose(); if (o.material) { if (Array.isArray(o.material)) o.material.forEach(m=>m.dispose()); else o.material.dispose(); } });
  worldGroup = new THREE.Group(); scene.add(worldGroup);
  interactables=[]; enemy=null; exitObject=null; panelObject=null;
}
function addItem(x,z,label,kind='item') {
  const g = new THREE.Group(); g.position.set(x,.45,z);
  const base = new THREE.Mesh(new THREE.BoxGeometry(.38,.42,.28),material(kind==='key'?0xc2a45e:kind==='fuse'?0x9ba8a7:0x769b82,.45,{emissive:0x18291d,emissiveIntensity:.5}));
  base.rotation.y=.3; base.castShadow=true; g.add(base);
  const glow = new THREE.PointLight(kind==='key'?0xffc85c:0x7ab6a1, .45, 2.2); glow.position.y=.3; g.add(glow);
  g.userData={label,kind,found:false}; worldGroup.add(g); interactables.push(g); return g;
}
function addDoor(x,z) {
  const g=new THREE.Group(); g.position.set(x,1.35,z);
  const door=box(g,0,0,0,1.65,2.7,.18,material(0x171c1d),{castShadow:true});
  const knob=new THREE.Mesh(new THREE.SphereGeometry(.07,8,6),material(0xb9a46c,.4,{metalness:.6})); knob.position.set(.55,-.1,-.12); g.add(knob);
  g.userData={kind:'exit',label:'Pintu keluar'}; worldGroup.add(g); interactables.push(g); exitObject=g; return g;
}
function buildWorld() {
  clearWorld();
  const cfg=MAPS[selectedMap], diff=DIFFICULTY[selectedDifficulty];
  scene.fog.density = selectedDifficulty==='nightmare' ? .052 : selectedDifficulty==='medium' ? .044 : .038;
  scene.fog.color.set(selectedMap==='hospital'?0x0a1110:0x070b0d);
  scene.background.set(0x050708);
  const wallMat=material(cfg.color), floorMat=material(cfg.floor), ceilingMat=material(0x0b0d0e), supportMat=material(0x171b1c), grime=material(0x202626);
  const L=cfg.length,W=cfg.width;
  box(worldGroup,0,-.22,-L/2,W,.4,L,floorMat,{castShadow:false});
  box(worldGroup,0,3.5,-L/2,W,.35,L,ceilingMat,{castShadow:false});
  box(worldGroup,-W/2-.18,1.55,-L/2,.36,3.5,L,wallMat);
  box(worldGroup,W/2+.18,1.55,-L/2,.36,3.5,L,wallMat);
  // End wall behind the player and exit wall.
  box(worldGroup,0,1.55,.2,W,3.5,.35,wallMat);
  box(worldGroup,0,1.55,-L-.15,W,3.5,.35,wallMat);
  // Repeating structural ribs and puddle-like dark floor patches.
  const ribs = selectedMap==='house'?6:Math.floor(L/4);
  for(let i=1;i<ribs;i++){
    const z=-i*(L/ribs);
    if(selectedMap==='tunnel'){
      box(worldGroup,-W/2+.35,1.6,z,.3,3.2,.42,supportMat);
      box(worldGroup,W/2-.35,1.6,z,.3,3.2,.42,supportMat);
      box(worldGroup,0,3.15,z,W,.25,.42,supportMat);
    } else {
      box(worldGroup,-W/2+.2,1.6,z,.3,3.2,.4,supportMat);
      box(worldGroup,W/2-.2,1.6,z,.3,3.2,.4,supportMat);
      if(selectedMap==='house' && i%2===0) {
        box(worldGroup,-W/2+2,1.4,z-1,3,2.8,.22,wallMat);
        box(worldGroup,W/2-2,1.4,z-1,3,2.8,.22,wallMat);
      }
    }
    if(i%2===0){
      const patch=box(worldGroup,(Math.random()-.5)*(W-2),-.012,z-1,1+Math.random()*2,.015,1+Math.random()*2,grime,{castShadow:false});
      patch.rotation.y=Math.random()*2;
    }
    if(i%3===0) makeLamp((Math.random()-.5)*W,3.05,z,selectedMap==='hospital'?0x668e7d:0x8b9eaa,selectedDifficulty==='nightmare'?.45:.75);
  }
  // Set dressing: crates, pipes, broken cabinets and beams.
  const decorCount=selectedMap==='house'?26:20;
  for(let i=0;i<decorCount;i++){
    const z=-3-Math.random()*(L-7), side=Math.random()<.5?-1:1;
    const x=side*(W/2-1.1-Math.random()*1.3);
    const h=.35+Math.random()*1.1, size=.35+Math.random()*.7;
    const obj=box(worldGroup,x,h/2,z,size,h,size,Math.random()<.5?supportMat:grime);
    if(selectedMap==='hospital' && i%4===0) obj.rotation.z=.12;
  }
  // Exit and objective panel sit at the far end.
  addDoor(0,-L+1.2);
  panelObject=box(worldGroup,selectedMap==='house'?W/2-1.2:1.1,1.2,-L+3,.55,.9,.2,material(0x293331,.5,{emissive:0x163f2b,emissiveIntensity:.25}));
  panelObject.userData={kind:'panel',label:selectedMap==='house'?'Kotak kunci':'Panel darurat'};
  interactables.push(panelObject);
  requiredItems=diff.items;
  const itemKinds = selectedMap==='house'?['key','key','key','key','key']:['fuse','fuse','fuse','fuse','fuse'];
  for(let i=0;i<requiredItems;i++){
    const z=-5-(i+1)*(L-10)/(requiredItems+1);
    let x=(Math.random()-.5)*(W-3);
    if(selectedMap==='house') x=(i%2===0?-1:1)*(W/2-3-Math.random()*2);
    addItem(x,z,selectedMap==='house'?`Kunci ${i+1}`:`Komponen ${i+1}`,itemKinds[i]);
  }
  // Distinct hospital bed-like props and house furniture silhouettes.
  if(selectedMap==='hospital'){
    for(let i=0;i<5;i++){
      const z=-6-i*6;
      box(worldGroup,-W/2+2,.45,z,2.1,.3,1.1,material(0x3d4845));
      box(worldGroup,-W/2+2,1.1,z,.12,1.1,.12,supportMat);
      box(worldGroup,-W/2+2.9,1.1,z,.12,1.1,.12,supportMat);
    }
  } else if(selectedMap==='house'){
    for(let i=0;i<5;i++){
      const z=-5-i*6;
      box(worldGroup,W/2-3,.6,z,2.2,1.1,1.1,material(0x302521));
      box(worldGroup,W/2-3,1.25,z,.15,.22,1.1,supportMat);
    }
  }
  enemy=createEnemy();
  player.x=0; player.z=1.4; player.yaw=0; player.pitch=0; player.stamina=100; player.battery=diff.battery; player.health=100; player.crouched=false;
  camera.position.set(0,1.65,1.4); camera.rotation.order='YXZ'; camera.rotation.set(0,0,0);
  collected=0; enemyState='patrol'; enemyTimer=0; flickerTimer=0; exitUnlocked=false; gameTime=0; lastNoise=0;
  $('difficultyTag').textContent=diff.label;
  updateObjective();
}
function updateObjective() {
  const cfg=MAPS[selectedMap];
  if(exitUnlocked) $('objectiveText').textContent='Jalan keluar terbuka. Lari ke pintu!';
  else if(collected>=requiredItems) $('objectiveText').textContent=selectedMap==='house'?'Semua kunci ditemukan. Aktifkan kotak kunci!':'Semua komponen ditemukan. Aktifkan panel darurat!';
  else $('objectiveText').textContent=cfg.objective;
  $('itemCount').textContent=`Barang: ${collected} / ${requiredItems}`;
}
function startGame() {
  buildWorld(); running=true; paused=false; ended=false;
  $('hud').classList.remove('hidden'); hideOverlay();
  startAudio();
  renderer.domElement.requestPointerLock?.();
  clock.getDelta();
  showToast(`${MAPS[selectedMap].label}: jangan membuat terlalu banyak suara.`);
}
function pauseGame() {
  if(!running || ended) return;
  paused=true; keysDown.clear();
  if(document.pointerLockElement) document.exitPointerLock();
  setView('pauseMenu');
}
function resumeGame() {
  if(!running || ended) return;
  paused=false; hideOverlay(); renderer.domElement.requestPointerLock?.(); clock.getDelta();
}
function finishGame(won) {
  ended=true; running=false; paused=true;
  if(document.pointerLockElement) document.exitPointerLock();
  $('hud').classList.add('hidden');
  $('endTitle').textContent=won?'KAMU BERHASIL KELUAR':'KAMU TERTANGKAP';
  $('endText').textContent=won?'Pintu tertutup di belakangmu. Untuk malam ini, kamu selamat.':'Sosok itu menemukanmu dalam gelap. Coba lagi dengan strategi berbeda.';
  setView('endMenu');
}
function startAudio() {
  if(audioCtx) { if(audioCtx.state==='suspended') audioCtx.resume(); return; }
  try {
    audioCtx = new (window.AudioContext || window.webkitAudioContext)();
    const osc=audioCtx.createOscillator(), gain=audioCtx.createGain(), filter=audioCtx.createBiquadFilter();
    osc.type='triangle'; osc.frequency.value=48; filter.type='lowpass'; filter.frequency.value=115;
    gain.gain.value=(settings.volume/100)*.045;
    osc.connect(filter); filter.connect(gain); gain.connect(audioCtx.destination); osc.start();
    ambienceGain=gain;
    // Slow, subtle wind-like modulation generated locally; no external audio files.
    const lfo=audioCtx.createOscillator(), lfoGain=audioCtx.createGain();
    lfo.frequency.value=.13; lfoGain.gain.value=13; lfo.connect(lfoGain); lfoGain.connect(osc.frequency); lfo.start();
  } catch { /* Audio is optional; gameplay still works without Web Audio. */ }
}
function playScareTone() {
  if(!audioCtx || settings.volume===0) return;
  try {
    const osc=audioCtx.createOscillator(), gain=audioCtx.createGain();
    osc.type='sawtooth'; osc.frequency.setValueAtTime(110,audioCtx.currentTime);
    osc.frequency.exponentialRampToValueAtTime(42,audioCtx.currentTime+.6);
    gain.gain.setValueAtTime(settings.volume/100*.06,audioCtx.currentTime);
    gain.gain.exponentialRampToValueAtTime(.001,audioCtx.currentTime+.7);
    osc.connect(gain); gain.connect(audioCtx.destination); osc.start(); osc.stop(audioCtx.currentTime+.72);
  } catch {}
}
function interact() {
  if(!running || paused || ended) return;
  raycaster.setFromCamera(new THREE.Vector2(0,0),camera);
  const hits=raycaster.intersectObjects(interactables,true);
  const hit=hits.find(h=>h.distance<2.7);
  if(!hit){ showToast('Tidak ada yang bisa digunakan di dekatmu.'); return; }
  let target=hit.object;
  while(target.parent && !target.userData.kind) target=target.parent;
  const data=target.userData;
  if(data.kind==='item' || data.kind==='key' || data.kind==='fuse') {
    if(data.found) return;
    data.found=true; target.visible=false; collected++;
    showToast(`${data.label} ditemukan.`);
    updateObjective();
    if(collected>=requiredItems) showToast('Semua barang ditemukan. Cari panel darurat!');
    lastNoise=gameTime; enemyState='investigate';
  } else if(data.kind==='panel') {
    if(collected<requiredItems){ showToast(`Masih kurang ${requiredItems-collected} barang.`); return; }
    exitUnlocked=true; exitObject.userData.unlocked=true;
    exitObject.children[0].material.color.set(0x3d604c);
    showToast('Pintu terbuka! Cepat keluar!');
    updateObjective(); lastNoise=gameTime;
  } else if(data.kind==='exit') {
    if(!exitUnlocked){ showToast('Pintu terkunci. Cari semua barang dan aktifkan panel.'); return; }
    finishGame(true);
  }
}
function handleKeyDown(e) {
  if(remapAction) {
    e.preventDefault();
    const code=e.code;
    const duplicate=Object.entries(keyBindings).find(([a,c])=>a!==remapAction&&c===code);
    if(duplicate){ showToast(`Tombol sudah dipakai: ${ACTION_NAMES[duplicate[0]]}`); remapAction=null; renderBindings(); return; }
    keyBindings[remapAction]=code; remapAction=null;
    localStorage.setItem('tle-settings',JSON.stringify({...settings,keys:keyBindings}));
    renderBindings(); return;
  }
  if(['Space','ArrowUp','ArrowDown','ArrowLeft','ArrowRight'].includes(e.code)) e.preventDefault();
  if(e.code===keyBindings.pause) { if(running&&!paused) pauseGame(); else if(running&&paused&&!ended) resumeGame(); return; }
  if(paused || !running) return;
  keysDown.add(e.code);
  if(e.code===keyBindings.interact && !e.repeat) interact();
  if(e.code===keyBindings.flashlight && !e.repeat) { flashlight.visible=!flashlight.visible; showToast(flashlight.visible?'Senter dinyalakan.':'Senter dimatikan.'); }
}
function handleKeyUp(e){ keysDown.delete(e.code); }
function handleMouseMove(e) {
  if(!pointerLocked || paused || !running) return;
  const sens=(settings.sensitivity||.8)*.0017;
  player.yaw-=e.movementX*sens; player.pitch-=e.movementY*sens;
  player.pitch=THREE.MathUtils.clamp(player.pitch,-1.45,1.45);
  camera.rotation.set(player.pitch,player.yaw,0,'YXZ');
}
function updatePlayer(dt) {
  const k=keyBindings;
  const f=(keysDown.has(k.forward)?1:0)-(keysDown.has(k.back)?1:0);
  const s=(keysDown.has(k.right)?1:0)-(keysDown.has(k.left)?1:0);
  const runningFast=keysDown.has(k.run)&&player.stamina>0&&f>0;
  player.crouched=keysDown.has(k.crouch);
  if(runningFast) player.stamina=Math.max(0,player.stamina-dt*23); else player.stamina=Math.min(100,player.stamina+dt*13);
  const speed=(player.crouched?1.45:runningFast?5.3:3.05);
  const angle=player.yaw;
  const dx=(Math.sin(angle)*f+Math.cos(angle)*s)*speed*dt;
  const dz=(-Math.cos(angle)*f+Math.sin(angle)*s)*speed*dt;
  const nx=player.x+dx, nz=player.z+dz;
  const cfg=MAPS[selectedMap], halfW=cfg.width/2-.8;
  if(Math.abs(nx)<halfW && nz<1.5 && nz>-cfg.length+.9){ player.x=nx; player.z=nz; }
  camera.position.x=player.x; camera.position.z=player.z;
  camera.position.y=player.crouched?1.05:1.65;
  if(runningFast && (f||s)) lastNoise=gameTime;
  $('soundStatus').textContent=player.crouched?'SUARA: RENDAH':runningFast?'SUARA: KERAS':'SUARA: TENANG';
  $('flashlightStatus').textContent=`▰ SENTER: ${flashlight.visible?'NYALA':'MATI'} · BATERAI ${Math.ceil(player.battery)}%`;
  const promptEl=$('prompt');
  raycaster.setFromCamera(new THREE.Vector2(0,0),camera);
  const hits=raycaster.intersectObjects(interactables,true).filter(h=>h.distance<2.7);
  if(hits.length) promptEl.textContent=`[${formatKey(keyBindings.interact)}] INTERAKSI`; else promptEl.textContent='';
  player.battery=Math.max(0,player.battery-dt*(flashlight.visible?.22:.03));
  if(player.battery<=0) flashlight.visible=false;
  flashlight.intensity=player.battery<15?20:34;
  if(player.battery<15 && Math.random()<dt*.5) flashlight.visible=false;
}
function updateEnemy(dt) {
  if(!enemy) return;
  enemyTimer+=dt;
  const ep=enemy.position, dist=Math.hypot(player.x-ep.x,player.z-ep.z);
  const diff=DIFFICULTY[selectedDifficulty];
  const heard=gameTime-lastNoise<5 && !player.crouched;
  const seesPlayer=dist<12 && flashlight.visible;
  if(dist<11 && (heard||seesPlayer||enemyState==='chase')) enemyState='chase';
  else if(heard && dist<20 && enemyState!=='chase') enemyState='investigate';
  else if(enemyState==='chase'&&dist>17) enemyState='investigate';
  if(enemyState==='chase') {
    const dx=player.x-ep.x,dz=player.z-ep.z;
    const d=Math.max(.001,Math.hypot(dx,dz));
    const sp=(selectedDifficulty==='nightmare'?2.55:selectedDifficulty==='medium'?2.05:1.65)*diff.chase;
    ep.x+=dx/d*sp*dt; ep.z+=dz/d*sp*dt;
    enemy.lookAt(player.x,0,player.z);
    if(dist<1.2){ playScareTone(); finishGame(false); }
  } else if(enemyState==='investigate') {
    const targetZ=player.z+(player.crouched?5:0);
    const dx=player.x-ep.x,dz=targetZ-ep.z,d=Math.max(.001,Math.hypot(dx,dz));
    ep.x+=dx/d*.9*dt; ep.z+=dz/d*.9*dt;
    if(dist>16 || enemyTimer>10){ enemyState='patrol'; enemyTimer=0; }
  } else {
    ep.x=Math.sin(gameTime*.32+enemy.userData.phase)*Math.min(3,MAPS[selectedMap].width/4);
    ep.z=enemy.userData.home.z+Math.sin(gameTime*.2)*3;
    enemy.rotation.y=Math.sin(gameTime*.3)*.3;
  }
  // A brief apparition when the player looks away; it fades back into fog.
  const facing = new THREE.Vector3(0,0,-1).applyQuaternion(camera.quaternion);
  tmpVec.set(ep.x-player.x,0,ep.z-player.z).normalize();
  const dot=facing.x*tmpVec.x+facing.z*tmpVec.z;
  enemy.traverse(o=>{ if(o.material && o.material.transparent!==true){ o.material.transparent=true; } if(o.material) o.material.opacity=(dot<-.65 && dist<16)?0.72:1; });
  $('soundStatus').textContent=enemyState==='chase'?'SUARA: DIA MENGEJAR!':player.crouched?'SUARA: RENDAH':(gameTime-lastNoise<4?'SUARA: KERAS':'SUARA: TENANG');
}
function updateAtmosphere(dt) {
  gameTime+=dt;
  if(toastTimer>0){ toastTimer-=dt; if(toastTimer<=0) $('toast').classList.remove('visible'); }
  if(flashlight.visible) {
    flickerTimer-=dt;
    if(flickerTimer<=0) {
      flickerTimer=.4+Math.random()*2.5;
      const chance=DIFFICULTY[selectedDifficulty].flicker;
      if(Math.random()<chance) { flashlight.intensity=4; setTimeout(()=>{if(flashlight) flashlight.intensity=player.battery<15?20:34;},80+Math.random()*140); }
    }
  }
  if(ambientLight) ambientLight.intensity=.32+Math.sin(gameTime*.18)*.025;
}
function animate() {
  requestAnimationFrame(animate);
  const dt=Math.min(clock.getDelta(),.05);
  if(running&&!paused&&!ended) { updatePlayer(dt); updateEnemy(dt); updateAtmosphere(dt); }
  renderer.render(scene,camera);
}
document.addEventListener('keydown',handleKeyDown);
document.addEventListener('keyup',handleKeyUp);
document.addEventListener('mousemove',handleMouseMove);
document.addEventListener('pointerlockchange',()=>{
  pointerLocked=document.pointerLockElement===renderer?.domElement;
  if(running&&!paused&&!ended&&!pointerLocked) pauseGame();
});
document.addEventListener('visibilitychange',()=>{if(document.hidden&&running&&!paused)pauseGame();});
renderer; // keep module initialization order explicit
setupMenu();
initThree();
animate();
