import express from 'express';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const app = express();
const __dirname = path.dirname(fileURLToPath(import.meta.url));
const distPath = path.join(__dirname, 'dist');
const port = Number(process.env.PORT || 3000);

app.disable('x-powered-by');
app.use(express.static(distPath, {
  etag: true,
  maxAge: '1h',
  setHeaders(res, filePath) {
    if (filePath.endsWith('.html')) res.setHeader('Cache-Control', 'no-cache');
  }
}));
app.get('*', (_req, res) => res.sendFile(path.join(distPath, 'index.html')));
app.listen(port, '0.0.0.0', () => {
  console.log(`The Last Exit is listening on http://0.0.0.0:${port}`);
});