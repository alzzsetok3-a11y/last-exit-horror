# HORROR: THE LAST EXIT

Playable single-player browser horror MVP built with Three.js, Vite, and Express. All gameplay geometry is procedural; no paid assets or API keys are required.

## Requirements
- Node.js 20+ recommended
- npm
- Modern desktop browser with WebGL

## Local development
```bash
npm install
npm run dev
```
Open http://localhost:5173

## Production build
```bash
npm run build
npm start
```
Express serves `dist/` on port 3000 by default. Set `PORT` to change it.

## Ubuntu VPS with PM2
```bash
sudo apt update
sudo apt install -y nodejs npm
node --version
npm --version
```
Use a current Node.js 20+ installation if Ubuntu's repository provides an older version. Then upload/extract the project and run:
```bash
cd last-exit-horror
npm install
npm run build
sudo npm install -g pm2
pm2 start server.js --name last-exit-horror
pm2 save
pm2 startup
```
Run the command printed by `pm2 startup` as instructed, then:
```bash
sudo ufw allow OpenSSH
sudo ufw allow 3000/tcp
sudo ufw enable
```
Open `http://YOUR_VPS_IP:3000`. For public testing only; use HTTPS/reverse proxy before any real public deployment. Do not expose the Vite dev server to the public internet.

## Controls
- W/A/S/D: move
- Mouse: look around (click canvas/menu start to acquire pointer lock)
- Shift: run; Ctrl: crouch
- E: interact/pick up/use
- F: flashlight
- Esc: pause / release mouse lock

Controls and graphics settings are stored in browser `localStorage`. Rebind keys in Control Settings. Duplicate bindings are rejected.

## MVP notes
The game uses simple generated meshes, local Web Audio ambience, basic pursuit AI, and simple collision bounds. It is a playable prototype, not a production horror title. The font stylesheet has a system-font fallback; no gameplay assets are loaded from third parties.
